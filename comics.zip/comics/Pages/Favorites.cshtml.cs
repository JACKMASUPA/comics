using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace comics.Pages
{
    public class FavoritesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
