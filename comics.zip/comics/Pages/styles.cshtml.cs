using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace comics.Pages
{
    public class stylesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
