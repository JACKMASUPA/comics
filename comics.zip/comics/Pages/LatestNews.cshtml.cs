using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace comics.Pages
{
    public class LatestNewsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
